﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _004_Uppgift_5
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.ForegroundColor = ConsoleColor.Yellow;
            string Username;
            //Can't greet anybody without knowing a name or title now can I? The rest below is my AWESOME introduction.
            Console.WriteLine("           ___________________________________________________            ");
            Console.WriteLine("          |                                                   |           ");
            Console.WriteLine("          |      Salutations! Brave hero of the class!        |           ");
            Console.WriteLine("          |           Welcome to the legendary storage        |           ");
            Console.WriteLine("          |              of Higher Knowledge!                 |           ");
            Console.WriteLine("          |                                                   |           ");
            Console.WriteLine("          |___________________________________________________|           ");
            Console.WriteLine();
            Console.WriteLine();
            Console.WriteLine();
            Console.WriteLine("First, we'd like you to enter your name. When you've done that press enter. You can write in anything you'd like for a name if you don't want to use your real  one.");
            Username = Console.ReadLine();
            Console.WriteLine();
            Console.WriteLine();
            Console.WriteLine("Greetings, " + Username);
            Console.WriteLine("Welcome to this storage of Higher Knowledge.");
            Console.WriteLine("You will be able to chose from four different subjects in which to expand your knowledge with the legendary Higher Knowledge.");
            Console.WriteLine("So let's get this show on the road shall we?");
            Console.WriteLine("To proceed, press enter repetedly.");
            Console.ReadLine();
            Console.Clear();
            Console.ReadKey();

            

            while (true)
            {

                Console.WriteLine("Here are your topics of study:");
                Console.WriteLine("To study Disturbed press A.");
                Console.WriteLine("To study Parkway Drive press B");
                Console.WriteLine("To study Hammerfall press C");
                Console.WriteLine("To exit press E");

                //Användaren inmatning för val av ämne.
                string userInput = Console.ReadLine();
                userInput = userInput.ToLower();

                //För och avlusta programmet om användaren skriver in bokstaven e.
                if (userInput == "e")
                {
                    Environment.Exit(1);
                }
                
                //Switch liknar if-satser men istället för och fylla upp med en massa else if vid många olika utfall skriver man bara olika cases. Ganska praktiskt.
                switch (userInput)
                {
                    //Kan jämnföras med if-sats. Olika alternativ där vissa parametrar måste stämma för och köra visa bitar av koden.
                    case "a":
                        Console.WriteLine("You've chosen to study Disturbed");
                        Console.Clear();
                        Console.WriteLine("Disturbed is an American heavy metal band from Chicago, Illinois.");
                        Console.WriteLine("The band's members are vocalist David Draiman, guitarist Dan Donegan, bassist John Moyer, and drummer Mike Wengren.");
                        Console.WriteLine("Former band members were vocalist Erich Awalt and bassist Steve 'Fuzz' Kmak. Formed in 1994 as Brawl, the band was renamed Disturbed in 1996 after Draiman was hired as the band's new vocalist.");
                        Console.WriteLine("Since the band's formation, they have sold over 13 million albums worldwide, making them one of the largest grossing metal/rock bands in recent years.");
                        Console.WriteLine("The band has released five studio albums, four of which have consecutively debuted at number-one on the Billboard 200.");
                        Console.WriteLine("The band went into an indefinite hiatus in October 2011 and the band's members are currently working on various side projects. The band members insist that they will regroup as Disturbed again sometime in the future.");
                        Console.WriteLine("Before vocalist David Draiman joined Disturbed, they were known as Brawl. Brawl's lineup consisted of vocalist Erich Awalt, guitarist Dan Donegan, drummer Mike Wengren, and bassist Steve 'Fuzz' Kmak.");
                        Console.WriteLine("Before changing their name to 'Brawl', however, Donegan mentioned in the band's DVD, Decade of Disturbed, that the name was originally going to be 'Crawl', they switched it to 'Brawl', due to the name already being used by another band.");
                        Console.WriteLine("Awalt left the band shortly after the recording of a demo tape; the other three members advertised for a singer. They posted an advertisement in the local music publication in Chicago, Illinois, called the 'Illinois Entertainer'.");
                        Console.WriteLine("Draiman answered the advertisement after going to twenty other auditions that month. Guitarist Dan Donegan commented on Draiman: 'You know, out of all the singers that we had talked to or auditioned, he [Draiman] was the only singer who was ready to go with originals. And that impressed me, just to attempt that'.");
                        Console.WriteLine("With regard to Draiman being the new singer for the band, Donegan said, 'After a minute or two, he just starts banging out these melodies that were huge... I'm playing my guitar and I'm grinning from ear to ear, trying not to give it away that I like this guy, you know, because I don't want to, you know... say 'Yeah, we'll give you a call back. We'll, you know, discuss it.'");
                        Console.WriteLine("But I was so psyched. Chill up my spine. I'm like, 'There is something here'. As drummer Mike Wengren commented, 'We clicked right off the bat.' Draiman then joined the band in 1996 and the band was renamed Disturbed.");
                        Console.WriteLine("When asked in an interview why he suggested to name the band Disturbed, Draiman said, 'It had been a name I have been contemplating for a band for years. It just seems to symbolize everything we were feeling at the time. The level of conformity that people are forced into was disturbing to us and we were just trying to push the envelope and the name just sorta made sense.'");
                        Console.WriteLine("");
                        Console.WriteLine("");
                        Console.WriteLine("Hungry for more are ya? Well to bad, I can't give away all my secrets now can i?");
                        Console.WriteLine("Press enter a few times to get back to the main page.");
                        Console.ReadKey();
                        Console.Clear();
                        break;
                    //Utan ett break som avslutar switch-satsen så skulle den bara fortsätta tills den tar slut då det inte är några klammerparenteser som markerar början och slut för varje alternativ i switch-satsen.

                    case "b":
                        Console.WriteLine("Parkway Drive is an Australian metalcore band from Byron Bay, New South Wales, formed in 2002. As of 2013, Parkway Drive has released four full-length albums and one book called Ten Years of Parkway Drive");
                        Console.WriteLine("Parkway Drive was formed at the end of 2002. Their name is from the band's hometown in Byron Bay, New South Wales, where the group practiced in the basement of a members home, called the 'Parkway House', on Parkway Drive – the street's name.");
                        Console.WriteLine("Not long after their initial breakthrough, they released a split EP with metalcore band I Killed the Prom Queen, entitled I Killed the Prom Queen / Parkway Drive: Split CD in 2003.");
                        Console.WriteLine("Parkway Drive also made an appearance on The Red Sea compilation What We've Built, preceded by their EP, Don't Close Your Eyes. After their first EP release they split ways with original bassist Brett Versteeg who was replaced by Shaun Cash.");
                        Console.WriteLine("In May 2005, they headed to America to record their debut album with metal producer, Adam Dutkiewicz from the band Killswitch Engage whose production credits include Unearth and Underoath.");
                        Console.WriteLine("Since the release of Don't Close Your Eyes, Parkway Drive have rapidly accumulated a fanbase Australia-wide, courtesy of support slots for international acts including Hatebreed, In Flames, Chimaira, Shadows Fall, As I Lay Dying, Bleeding Through,");
                        Console.WriteLine(" Alexisonfire, and performances at Metal for the Brain 2005 and Australia's Hardcore 2005.");
                        Console.WriteLine("In late May 2006, bass player Shaun Cash left the band for personal reasons with full support from the rest of the members.");
                        Console.WriteLine("The band soon found a replacement in their merch guy' and long-time friend, Jia 'Pie' O'Connor, who didn't know how to play the bass at the time, and got 3 days to learn the songs.");
                        Console.WriteLine("Now a permanent part of the line-up, he played with them for the rest of their first international tour in the United Kingdom and Europe, and later dates in the United States.");
                        Console.WriteLine("In October 2006, they were billed as the Australian contingent on the Rockstar Taste of Chaos tour, playing alongside Anti-Flag, Underoath, Thursday, Senses Fail, Taking Back Sunday and Saosin. During November and December 2006, they appeared at the Homebake Festival,");
                        Console.WriteLine(" Sound Fest, Resist Records' tour, Soundwave Festival and Gravity G Festival before returning to the UK and Europe.");
                         Console.WriteLine("");
                        Console.WriteLine("");
                        Console.WriteLine("Hungry for more are ya? Well to bad, I can't give away all my secrets now can i?");
                        Console.WriteLine("Press enter a few times to get back to the main page.");
                        Console.ReadKey();
                        Console.Clear();
                        break;

                    case "c":
                        Console.WriteLine("HammerFall was formed when guitarist Oscar Dronjak quit Ceremonial Oath and invited Jesper Strömblad (from In Flames) to join him as a drummer in a new musical project he had been contemplating for some time. Dronjak had already composed the song 'Steel Meets Steel' which was later included on HammerFall's debut album.");
                        Console.WriteLine("Dronjak and Strömblad were later joined by guitarist Niklas Sundin, bassist Johan Larsson, and vocalist Mikael Stanne. When Niklas Sundin and Johan Larsson left HammerFall the following year, Glenn Ljungström (then guitarist of In Flames) and Fredrik Larsson (bassist of the former Swedish death metal band Dispatched), replaced them.");
                        Console.WriteLine("All five members played in other bands at the time. Dronjak and Larsson played in Crystal Age; Strömblad and Ljungström played in In Flames and Stanne sang for Dark Tranquillity. Both of these bands influenced Swedish melodic death metal. HammerFall was relegated to being a side project of them all for several years.");
                        Console.WriteLine("Their concerts were limited mostly to a local music contest named Rockslaget. The band had few songs of their own and played mostly covers from bands such as Pretty Maids, Judas Priest and Alice Cooper.");
                        Console.WriteLine("In 1996, HammerFall reached the semi-finals of Rockslaget. When Mikael Stanne could not perform with the band in the semi-finals, they found Joacim Cans, who agreed to play with them for the night. The concert was a success although the judges disqualified HammerFall for the finals. By the end of that day, Joacim had already been made an official member of the band.");
                        Console.WriteLine("Hammerfall's album No Sacrifice, No Victory was released in February 2009. This album features a cover song My Sharona. The Album peaked at No. 38 on the Billboard heatseakers charts. A music video for the song 'Any Means Necessary' was released some time before the actual release of the album.");
                        Console.WriteLine("To kick off their new album, HammerFall toured all over the world with several support bands. In the summer 2010 the band played a couple of high profile festivals throughout Europe including Sonisphere Festival, High Voltage Festival, Metalcamp, Graspop Metal Meeting and many more. The summer tour was named 'Any Festival Necessary'.");
                        Console.WriteLine("Hammerfall's 8th album was released on May 18, 2011 (Sweden), May 20 (Europe), and June 7 (North America), under the name Infected. After several months of recordings in Göteborg, Sweden and Nashville, TN, the new studio album was finally finished in February. The European tour followed, under the name 'European Outbreak'.");
                        Console.WriteLine("Infected is also the first Hammerfall album not to feature the mascot, the knight Hector, on the cover.");
                        Console.WriteLine("In 2012, Hammerfall recorded a live DVD while performing a show in Dalhalla, Sweden, that featured some former band members as well as other special guests. The DVD celebrated 15 years of the band's existence, and was titled 'Gates of Dalhalla'.In 2013, HammerFall took a break and some time to spend with their families or side-works.");
                        Console.WriteLine("Oscar wrote a book about HammerFall, 'Legenden om Hammerfall', that was released on 24 October and tells of the band's events during the past 16 years, but it still exists only in Swedish.");
                        Console.WriteLine("New HammerFall album will be released by the end of the summer 2014.");
                         Console.WriteLine("");
                        Console.WriteLine("");
                        Console.WriteLine("Hungry for more are ya? Well to bad, I can't give away all my secrets now can i?");
                        Console.WriteLine("Press enter a few times to get back to the main page.");
                        Console.ReadKey();
                        Console.Clear();
                        break;

                    //Då vad användaren matar in inte stämmer med några andra parametrar så kommer den till default.
                    default:
                        Console.WriteLine("Invalid input, press enter to return to the main menu.");
                        Console.ReadKey();
                        Console.Clear();
                        break;
                }

                
            }

        }

    }
}
