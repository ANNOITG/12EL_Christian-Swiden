﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _004_Uppgift_5
{
    class Program
    {
        static void Main(string[] args)
        {
            string Username;
            //Can't greet anybody without knowing a name or title now can I? The rest below is my AWESOME introduction.
            Console.WriteLine("           ___________________________________________________            ");
            Console.WriteLine("          |                                                   |           ");
            Console.WriteLine("          |      Salutations! Brave hero of the class!        |           ");
            Console.WriteLine("          |           Welcome to the legendary storage        |           ");
            Console.WriteLine("          |              of Higher Knowledge!                 |           ");
            Console.WriteLine("          |                                                   |           ");
            Console.WriteLine("          |___________________________________________________|           ");
            Console.WriteLine();
            Console.WriteLine();
            Console.WriteLine();
            Console.WriteLine("First, we'd like you to enter your name. When you've done that press enter. You can write in anything you'd like for a name if you don't want to use your real  one.");
            Username = Console.ReadLine();
            Console.WriteLine();
            Console.WriteLine();
            Console.WriteLine("Greetings, " + Username);
            Console.WriteLine("Welcome to this storage of Higher Knowledge.");
            Console.WriteLine("You will be able to chose from four different subjects in which to expand your knowledge with the legendary Higher Knowledge.");
            Console.WriteLine("So let's get this show on the road shall we?");
            Console.WriteLine("To proceed, press enter repetedly.");
            Console.ReadLine();
            Console.Clear();
            Console.ReadKey();

            while (true)
            {
                Console.WriteLine("Here are your topics of study:");
                Console.WriteLine("To study Disturbed press A.");
                Console.WriteLine("To study Godsmack press B");
                Console.WriteLine("To study Parkway Drive press C");
                Console.WriteLine("To study  press D");
                Console.WriteLine("To exit press E");

                string userChoise;
                string choise1 = "a";
                string choise2 = "b";
                string choise3 = "c";
                string choise4 = "d";
                string choise5 = "e";
                userChoise = Console.ReadLine();
                userChoise = userChoise.ToLower();

                if (userChoise == choise1)
                {
                    Console.WriteLine("You've chosen to study Disturbed");
                    Console.Clear();
                    Console.WriteLine("Disturbed is an American heavy metal band from Chicago, Illinois.");
                    Console.WriteLine("The band's members are vocalist David Draiman, guitarist Dan Donegan, bassist John Moyer, and drummer Mike Wengren.");
                    Console.WriteLine("Former band members were vocalist Erich Awalt and bassist Steve 'Fuzz' Kmak. Formed in 1994 as Brawl, the band was renamed Disturbed in 1996 after Draiman was hired as the band's new vocalist.");
                    Console.WriteLine("Since the band's formation, they have sold over 13 million albums worldwide, making them one of the largest grossing metal/rock bands in recent years.");
                    Console.WriteLine("The band has released five studio albums, four of which have consecutively debuted at number-one on the Billboard 200.");
                    Console.WriteLine("The band went into an indefinite hiatus in October 2011 and the band's members are currently working on various side projects. The band members insist that they will regroup as Disturbed again sometime in the future.");
                    Console.WriteLine("Before vocalist David Draiman joined Disturbed, they were known as Brawl. Brawl's lineup consisted of vocalist Erich Awalt, guitarist Dan Donegan, drummer Mike Wengren, and bassist Steve 'Fuzz' Kmak.");
                    Console.WriteLine("Before changing their name to 'Brawl', however, Donegan mentioned in the band's DVD, Decade of Disturbed, that the name was originally going to be 'Crawl', they switched it to 'Brawl', due to the name already being used by another band.");
                    Console.WriteLine("Awalt left the band shortly after the recording of a demo tape; the other three members advertised for a singer. They posted an advertisement in the local music publication in Chicago, Illinois, called the 'Illinois Entertainer'.");
                    Console.WriteLine("Draiman answered the advertisement after going to twenty other auditions that month. Guitarist Dan Donegan commented on Draiman: 'You know, out of all the singers that we had talked to or auditioned, he [Draiman] was the only singer who was ready to go with originals. And that impressed me, just to attempt that'.");
                    Console.WriteLine("With regard to Draiman being the new singer for the band, Donegan said, 'After a minute or two, he just starts banging out these melodies that were huge... I'm playing my guitar and I'm grinning from ear to ear, trying not to give it away that I like this guy, you know, because I don't want to, you know... say 'Yeah, we'll give you a call back. We'll, you know, discuss it.'");
                    Console.WriteLine("But I was so psyched. Chill up my spine. I'm like, 'There is something here'. As drummer Mike Wengren commented, 'We clicked right off the bat.' Draiman then joined the band in 1996 and the band was renamed Disturbed.");
                    Console.WriteLine("When asked in an interview why he suggested to name the band Disturbed, Draiman said, 'It had been a name I have been contemplating for a band for years. It just seems to symbolize everything we were feeling at the time. The level of conformity that people are forced into was disturbing to us and we were just trying to push the envelope and the name just sorta made sense.'");
                    Console.WriteLine("");
                    Console.WriteLine("");
                    Console.WriteLine("Hungry for more are ya? Well to bad, I can't give away all my secrets now can i?");
                    Console.WriteLine("Press enter a few times to get back to the main page.");
                    Console.ReadKey();
                    Console.Clear();
                    continue;

                }

                if (userChoise == choise2)
                {
                    Console.WriteLine("Hungry for more are ya? Well to bad, I can't give away all my secrets now can i?");
                    Console.WriteLine("Press enter a few times to get back to the main page.");
                    Console.ReadKey();
                    Console.Clear();
                    continue;
                }

                if (userChoise == choise3)
                {
                    Console.WriteLine("Hungry for more are ya? Well to bad, I can't give away all my secrets now can i?");
                    Console.WriteLine("Press enter a few times to get back to the main page.");
                    Console.ReadKey();
                    Console.Clear();
                    continue;
                }

                if (userChoise == choise4)
                {
                    Console.WriteLine("Hungry for more are ya? Well to bad, I can't give away all my secrets now can i?");
                    Console.WriteLine("Press enter a few times to get back to the main page.");
                    Console.ReadKey();
                    Console.Clear();
                    continue;
                }

                if (userChoise == choise5)
                {
                    break;
                }
            }
            Environment.Exit(0);
            Console.ReadKey();

        }

    }
}
