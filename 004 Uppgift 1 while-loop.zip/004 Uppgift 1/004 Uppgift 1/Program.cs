﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication2
{
    class Program
    {
        static void Main(string[] args)
        {
            while (true)
            {
                Console.ForegroundColor = ConsoleColor.Yellow;
                int HighScore = 0;
                int Tries = 3;

                string Username;
                Console.WriteLine("           ___________________________________________________            ");
                Console.WriteLine("          |                                                   |           ");
                Console.WriteLine("          |      Salutations! Brave hero of the class!        |           ");
                Console.WriteLine("          |           Welcome to the legendary quiz           |           ");
                Console.WriteLine("          |              of General Knowledge!                |           ");
                Console.WriteLine("          |                                                   |           ");
                Console.WriteLine("          |___________________________________________________|           ");
                Console.WriteLine();
                Console.WriteLine();
                Console.WriteLine();
                Console.WriteLine("First you must enter you name.");
                Username = Console.ReadLine();
                Console.WriteLine();
                Console.WriteLine();
                Console.WriteLine("Greetings, " + Username);
                Console.WriteLine("The following quiz will test your wits and your knowledge of historical events  and complete nonsense that nobody ever cared about!");
                Console.WriteLine();
                Console.WriteLine("Close stranger or complete nutcase (hey, if the shoe fits...) that now sits by  the computer, best of luck!");
                Console.WriteLine("The rules are simple. You answer 10 questions and you get an unlimited amount of time and tries at each question.");
                Console.WriteLine("To proceed, press enter repetedly.");
                Console.ReadLine();
                Console.Clear();
                Console.ReadKey();

                Console.WriteLine("Quiz time! I hope you're ready for this...");
                Console.ReadKey();
                Console.Clear();


                while (Tries >= 0)
                {
                    Tries--;
                    Console.WriteLine("Question one: What do you test with a Turing Test?");
                    Console.Write("Answer: ");
                    string answer1 = "artificial intelligence";
                    string userAnswer1;
                    userAnswer1 = Console.ReadLine();
                    userAnswer1 = userAnswer1.ToLower();
                    if (userAnswer1 == answer1)
                    {
                        Console.WriteLine("Correct answer. Please press enter repetedly for the next stage.");
                        HighScore++;
                        Console.ReadKey();
                        Console.Clear();
                        break;
                    }
                    else
                    {
                        Console.WriteLine("Wrong answer. Sorry bud, keep at it! Just keep hitting enter 'til you get to the next stage.");
                        Console.ReadKey();
                        Console.Clear();
                    }
                }


                Tries = 3;
                while (Tries >= 0)
                {
                    Tries--;
                    Console.WriteLine("Question two: What was Don Diego de la Vegas secret identity?");
                    Console.Write("Answer: ");
                    string answer2 = "zorro";
                    string userAnswer2;
                    userAnswer2 = Console.ReadLine();
                    userAnswer2 = userAnswer2.ToLower();
                    if (userAnswer2 == answer2)
                    {
                        Console.WriteLine("Correct answer. Please press enter repetedly for the next stage.");
                        HighScore++;
                        Console.ReadKey();
                        Console.Clear();
                        break;
                    }
                    else
                    {
                        Console.WriteLine("Wrong answer. Sorry bud, keep at it! Just keep hitting enter 'til you get to the next stage.");
                        Console.ReadKey();
                        Console.Clear();

                    }
                }

                Tries = 3;
                while (Tries >= 0)
                {
                    Tries--;
                    Console.WriteLine("Question three: What stage namne did the Brazilian soccer player Arthur Antunes Coimbra take?");
                    Console.Write("Answer: ");
                    string answer3 = "zico";
                    string userAnswer3;
                    userAnswer3 = Console.ReadLine();
                    userAnswer3 = userAnswer3.ToLower();
                    if (userAnswer3 == answer3)
                    {
                        Console.WriteLine("Correct answer. Please press enter repetedly for the next stage.");
                        HighScore++;
                        Console.ReadKey();
                        Console.Clear();
                        break;
                    }
                    else
                    {
                        Console.WriteLine("Wrong answer. Sorry bud, keep at it! Just keep hitting enter 'til you get to the next stage.");
                        Console.ReadKey();
                        Console.Clear();

                    }
                }

                Tries = 3;
                while (Tries >= 0)
                {
                    Tries--;
                    Console.WriteLine("Question four: From where does the group U2 hail?");
                    Console.Write("Answer: ");
                    string answer4 = "ireland";
                    string userAnswer4;
                    userAnswer4 = Console.ReadLine();
                    userAnswer4 = userAnswer4.ToLower();
                    if (userAnswer4 == answer4)
                    {
                        Console.WriteLine("Correct answer. Please press enter repetedly for the next stage.");
                        HighScore++;
                        Console.ReadKey();
                        Console.Clear();
                        break;
                    }
                    else
                    {
                        Console.WriteLine("Wrong answer. Sorry bud, keep at it! Just keep hitting enter 'til you get to the next stage.");
                        Console.ReadKey();
                        Console.Clear();
                    }
                }

                Tries = 3;
                while (Tries >= 0)
                {
                    Tries--;
                    Console.WriteLine("Question five: When was Nelson Mandela elected president?");
                    Console.Write("Answer: ");
                    string userAnswer5;
                    userAnswer5 = Console.ReadLine();
                    if (userAnswer5 == "1994" || userAnswer5 == "nineteen ninety four")
                    {
                        Console.WriteLine("Correct answer. Please press enter repetedly for the next stage.");
                        HighScore++;
                        Console.ReadKey();
                        Console.Clear();
                        break;
                    }
                    else
                    {
                        Console.WriteLine("Wrong answer. Sorry bud, keep at it! Just keep hitting enter 'til you get to the next stage.");
                        Console.ReadKey();
                        Console.Clear();
                    }
                }

                Tries = 3;
                while (Tries >= 0)
                {
                    Tries--;
                    Console.WriteLine("Question six: What root vegetable is used in the making of moonshine?");
                    Console.Write("Answer: ");
                    string answer6 = "potatos";
                    string userAnswer6;
                    userAnswer6 = Console.ReadLine();
                    userAnswer6 = userAnswer6.ToLower();
                    if (userAnswer6 == answer6)
                    {
                        Console.WriteLine("Correct answer. Please press enter repetedly for the next stage.");
                        HighScore++;
                        Console.ReadKey();
                        Console.Clear();
                        break;
                    }
                    else
                    {
                        Console.WriteLine("Wrong answer. Sorry bud, keep at it! Just keep hitting enter 'til you get to the next stage.");
                        Console.ReadKey();
                        Console.Clear();
                    }
                }

                Tries = 3;
                while (Tries >= 0)
                {
                    Tries--;
                    Console.WriteLine("Question seven: What company develops and manifactures the game console Wii?");
                    Console.Write("Answer: ");
                    string answer7 = "nitendo";
                    string userAnswer7;
                    userAnswer7 = Console.ReadLine();
                    userAnswer7 = userAnswer7.ToLower();
                    if (userAnswer7 == answer7)
                    {
                        Console.WriteLine("Correct answer. Please press enter repetedly fpr the next stage.");
                        HighScore++;
                        Console.ReadKey();
                        Console.Clear();
                        break;
                    }
                    else
                    {
                        Console.WriteLine("Wrong answer. Sorry bud, keep at it! Just keep hitting enter 'til you get to the next stage.");
                        Console.ReadKey();
                        Console.Clear();
                    }
                }

                Tries = 3;
                while (Tries >= 0)
                {
                    Tries--;
                    Console.WriteLine("Question eight: Which Nobel Laureates in Literature wrote the Jungle Book?");
                    Console.Write("Answer: ");
                    string answer8 = "rudyard kipling";
                    string userAnswer8;
                    userAnswer8 = Console.ReadLine();
                    userAnswer8 = userAnswer8.ToLower();
                    if (userAnswer8 == answer8)
                    {
                        Console.WriteLine("Correct answer. Please press enter repetedly for the next stage.");
                        HighScore++;
                        Console.ReadKey();
                        Console.Clear();
                        break;
                    }
                    else
                    {
                        Console.WriteLine("Wrong answer. Sorry bud, keep at it! Just keep hitting enter 'til you get to the next stage.");
                        Console.ReadKey();
                        Console.Clear();
                    }
                }

                Tries = 3;
                while (Tries >= 0)
                {
                    Tries--;
                    Console.WriteLine("Question nine: The famous Austrian composer Wolfgang Amadeus Mozart died in Vienna in 1791. What was his last work?");
                    Console.Write("Answer: ");
                    string answer9 = "requiem";
                    string userAnswer9;
                    userAnswer9 = Console.ReadLine();
                    userAnswer9 = userAnswer9.ToLower();
                    if (userAnswer9 == answer9)
                    {
                        Console.WriteLine("Correct answer. Please press enter repetedly for the next stage.");
                        HighScore++;
                        Console.ReadKey();
                        Console.Clear();
                        break;
                    }
                    else
                    {
                        Console.WriteLine("Wrong answer. Sorry bud, keep at it! Just keep hitting enter 'til you get to the next stage.");
                        Console.ReadKey();
                        Console.Clear();
                    }
                }

                Tries = 3;
                while (Tries >= 0)
                {
                    Tries--;
                    Console.WriteLine("Question ten: What was the name of the hot air balloon that Andreé tried to fly with over the North Pole?");
                    Console.Write("Answer: ");
                    string answer10 = "the eagle";
                    string userAnswer10;
                    userAnswer10 = Console.ReadLine();
                    userAnswer10 = userAnswer10.ToLower();
                    if (userAnswer10 == answer10)
                    {
                        Console.WriteLine("Correct answer. Please press enter repetedly for the next stage.");
                        HighScore++;
                        Console.ReadKey();
                        Console.Clear();
                        break;
                    }
                    else
                    {
                        Console.WriteLine("Wrong answer. Sorry bud, keep at it! Just keep hitting enter 'til you get to the next stag.");
                        Console.ReadKey();
                        Console.Clear();
                    }
                }
                if (HighScore == 10)
                    Console.WriteLine("Congratulations! You got a perfect score of 10!");
                else if (HighScore == 9 || HighScore == 8 || HighScore == 7)
                    Console.Write("Great Job!! You got a " + HighScore + "!!");
                else if (HighScore == 6 || HighScore == 5)
                    Console.Write("You got a " + HighScore + ", kinda good I guess");
                else if (HighScore < 5)
                    Console.Write("Your score is...     " + HighScore + "    unfortunately, you failed the quiz");

                string usersChoise;
                string choise1 = "y";
                string choise2 = "n";
                Console.WriteLine("Would you like to play again? Y/N?");
                usersChoise = Console.ReadLine();
                usersChoise = usersChoise.ToLower();


                if (usersChoise == choise1)
                {
                    Console.Clear();
                    continue;
                    
                }
                else if (usersChoise == choise2)
                {
                    break;
                }
                else
                {
                    Console.WriteLine("Not a viable choise. Y for yes or N for no only.");
                }
            }
            Environment.Exit(0);
            Console.ReadKey();
        }
    }
}
    