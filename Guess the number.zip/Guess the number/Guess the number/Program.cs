﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Guess_the_number
{
    class Program
    {
        static void Main(string[] args)
        {
            Random r = new Random();
            //The above code tells the computer to generate a random nummber and that below in which range (1-100) it is to generate a number.
            int random = r.Next(1, 100);
            //The next piece of awesome code is just to get an annoying yellow color on the text.
            Console.ForegroundColor = ConsoleColor.Yellow;

            int counter = 1;
            //A counter to see how many times the user guesses. 

            string Username;
            //Can't greet anybody without knowing a name or title now can I? The rest below is my AWESOME introduction.
            Console.WriteLine("           ___________________________________________________            ");
            Console.WriteLine("          |                                                   |           ");
            Console.WriteLine("          |      Salutations! Brave hero of the class!        |           ");
            Console.WriteLine("          |           Welcome to the legendary quiz           |           ");
            Console.WriteLine("          |              of Guess the Number!                 |           ");
            Console.WriteLine("          |                                                   |           ");
            Console.WriteLine("          |___________________________________________________|           ");
            Console.WriteLine();
            Console.WriteLine();
            Console.WriteLine();
            Console.WriteLine("First, we'd like you to enter your name. When you've done that press enter. You can write in anything you'd like for a name if you don't want to use your real  one.");
            Username = Console.ReadLine();
            Console.WriteLine();
            Console.WriteLine();
            Console.WriteLine("Greetings, " + Username);
            Console.WriteLine("So, a game of guess the number coming up.");
            Console.WriteLine("There are only one rule. You haft to use numbers and not letters when answering. Otherwise it's pretty straight forward.");
            Console.WriteLine("You get and unlimited amount of tries at it and you can always exit by closing the window.");
            Console.WriteLine("Press enter to continue.");
            Console.ReadKey();
            Console.Clear();


            while (true)
            {
                Console.WriteLine("Here we go. Enter a number between 1 and 100. Enter 0 to exit now if you're to scared to play.");
                //Where the user enters
                string inm = Console.ReadLine();

                //A way out in the beginning for the weak minded.
                if (inm == "0")
                {
                    Environment.Exit(0);
                }

                //Converts the string to a int.
                int giss = int.Parse(inm);


                //Tells the computer to pick up the random number and compare it to the users guess.
                int guess = random;
                int steps = Math.Abs(guess - random);
                //All the if's are if the user answers wrong. They'll pop up and torment the user more or less useless comments telling the user how far of they are.
                //The counter++ is to tell the computer how many tries the user had before he or she answered correctly.
                if (steps < 10)
                {
                    Console.WriteLine("Close. Damn close. Try again.");
                    Console.WriteLine("Press enter repetedly to proceed.");
                    counter++;
                    Console.ReadKey();
                    Console.Clear();
                }
                else if (steps < 20)
                {
                    Console.WriteLine("You're of by a few numbers, try it again.");
                    Console.WriteLine("Press enter repetedly to proceed.");
                    counter++;
                    Console.ReadKey();
                    Console.Clear();
                }
                else if (steps < 30)
                {
                    Console.WriteLine("You're of by 30 or less in one direction or another... Get a grip and guess right!");
                    Console.WriteLine("Press enter repetedly to proceed.");
                    counter++;
                    Console.ReadKey();
                    Console.Clear();
                }
                else if (steps < 40)
                {
                    Console.WriteLine("You're of by miles buddy. 40 or under of but keep trying. You're bound to get it right sometime...");
                    Console.WriteLine("Press enter repetedly to proceed.");
                    counter++;
                    Console.ReadKey();
                    Console.Clear();
                }
                else if (steps < 50)
                {
                    Console.WriteLine("Ain't exaktly going in the right direction here... You're of by at least 50!");
                    Console.WriteLine("Press enter repetedly to proceed.");
                    counter++;
                    Console.ReadKey();
                    Console.Clear();
                }
                else if (steps < 60)
                {
                    Console.WriteLine("Hold your horses! You're way of, 60 at minimum!");
                    Console.WriteLine("Press enter repetedly to proceed.");
                    counter++;
                    Console.ReadKey();
                    Console.Clear();
                }
                else if (steps < 70)
                {
                    Console.WriteLine("Yikes. This is BAD. You're of by 70 or there abouts. Try going down a few numbers will you?");
                    Console.WriteLine("Press enter repetedly to proceed.");
                    counter++;
                    Console.ReadKey();
                    Console.Clear();
                }
                else if (steps < 80)
                {
                    Console.WriteLine("Swinging a miss. 80 or there abouts of from target number. Should perhaps take it down a few?");
                    Console.WriteLine("Press enter repetedly to proceed.");
                    counter++;
                    Console.ReadKey();
                    Console.Clear();
                }
                else if (steps < 90)
                {
                    Console.WriteLine("Welcome. Hope you enjoy your stay here at the north pole. You're guess is that far of. 90 or so.");
                    Console.WriteLine("Press enter repetedly to proceed.");
                    counter++;
                    Console.ReadKey();
                    Console.Clear();
                }
                if (steps > 10)
                {
                    Console.WriteLine("You're cutting it pretty close there sport. Not that far of this time. Up a few and you'll be hitting spot on.");
                    Console.WriteLine("Press enter repetedly to proceed.");
                    counter++;
                    Console.ReadKey();
                    Console.Clear();
                }
                else if (steps > 20)
                {
                    Console.WriteLine("Close. You're of by 20 or thereabouts. Give it another go and you might just hit the jackpot.");
                    Console.WriteLine("Press enter repetedly to proceed.");
                    counter++;
                    Console.ReadKey();
                    Console.Clear();
                }
                else if (steps > 30)
                {
                    Console.WriteLine("Closing in on the jackpot but you're stil of by 30 or so.");
                    Console.WriteLine("Press enter repetedly to proceed.");
                    counter++;
                    Console.ReadKey();
                    Console.Clear();
                }
                else if (steps > 40)
                {
                    Console.WriteLine("Getting colder man. Don't let me freeze, hit the jackpot and warm things up! You're of with something around 40.");
                    Console.WriteLine("Press enter repetedly to proceed.");
                    counter++;
                    Console.ReadKey();
                    Console.Clear();

                }
                else if (steps > 50)
                {
                    Console.WriteLine("Cold. You're of by at least 50. Sure you're going for the jackpot and not a blizzard?");
                    Console.WriteLine("Press enter repetedly to proceed.");
                    counter++;
                    Console.ReadKey();
                    Console.Clear();
                }
                else if (steps > 60)
                {
                    Console.WriteLine("Sorry but you're of by quite a bit. 60 or more.");
                    Console.WriteLine("Press enter repetedly to proceed.");
                    counter++;
                    Console.ReadKey();
                    Console.Clear();
                }
                else if (steps > 70)
                {
                    Console.WriteLine("You're of by about 70 or so. Did you leave Windows open? It's getting pretty chilly.");
                    //Sorry about the pun, couldn't help myself ;)
                    Console.WriteLine("Press enter repetedly to proceed.");
                    counter++;
                    Console.ReadKey();
                    Console.Clear();
                }
                else if (steps > 80)
                {
                    Console.WriteLine("Are you going for a full monty? It's getting quite cold.");
                    Console.WriteLine("Press enter repetedly to proceed.");
                    counter++;
                    Console.ReadKey();
                    Console.Clear();
                }
                else if (steps > 90)
                {
                    Console.WriteLine("How's things over there at the south pol? Cold right? Well, it's colder here. 90 is one hell of a miss.");
                    Console.WriteLine("Press enter repetedly to proceed.");
                    counter++;
                    Console.ReadKey();
                    Console.Clear();
                }
                
                //For the the small chance that the user get's it right on the first try.
                if (counter == 1)
                {
                    Console.WriteLine("You got it right on the first try! Congratulations!");
                }
                if (giss == random)
                {
                    Console.WriteLine("Congratulations. You did it in " + counter + " tries.");
                }
                string usersChoise;
                string choise1 = "y";
                string choise2 = "n";
                Console.WriteLine("Would you like to play again? Y/N?");
                usersChoise = Console.ReadLine();
                usersChoise = usersChoise.ToLower();


                if (usersChoise == choise1)
                {
                    Console.Clear();
                    continue;

                }
                else if (usersChoise == choise2)
                {
                    break;
                }
                else
                {
                    Console.WriteLine("Not a viable choise. Y for yes or N for no only.");
                }
            }
            Environment.Exit(0);
            Console.ReadKey();

        }
    }
}