﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication2
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.ForegroundColor = ConsoleColor.Yellow;
            int HighScore = 0;

            string Username;
            Console.WriteLine("           ___________________________________________________            ");
            Console.WriteLine("          |                                                   |           ");
            Console.WriteLine("          |      Salutations! Brave hero of the class!        |           ");
            Console.WriteLine("          |           Welcome to the legendary quiz           |           ");
            Console.WriteLine("          |              of General Knowledge!                |           ");
            Console.WriteLine("          |                                                   |           ");
            Console.WriteLine("          |___________________________________________________|           ");
            Console.WriteLine();
            Console.WriteLine();
            Console.WriteLine();
            Console.WriteLine("First you must enter you name.");
            Username = Console.ReadLine();
            Console.WriteLine();
            Console.WriteLine();
            Console.WriteLine("Greetings, " + Username);
            Console.WriteLine("The following quiz will test your wits and your knowledge of historical events  and complete nonsense that nobody ever cared about!");
            Console.WriteLine();
            Console.WriteLine("Close stranger or complete nutcase (hey, if the shoe fits...) that now sits by  the computer, best of luck!");
            Console.ReadLine();
            Console.Clear();
            Console.ReadKey();

            Console.WriteLine("Quiz time! I hope you're ready for this...");
            Console.ReadLine();
            Console.Clear();
            Console.ReadKey();


            while (true)
            {
                Console.WriteLine("Question one: What do you test with a Turing Test?");
                Console.Write("Answer: ");
                string answer1 = "artificial intelligence";
                string userAnswer1;
                userAnswer1 = Console.ReadLine();
                userAnswer1 = userAnswer1.ToLower();
                if (userAnswer1 == answer1)
                {
                    Console.WriteLine("Correct answer. Please press enter for the next question.");
                    HighScore++;
                    break;
                }
                else
                {
                    Console.WriteLine("Wrong answer. Sorry bud, keep at it! Just keep hitting enter 'til you get the   question again.");
                    Console.ReadLine();
                    Console.Clear();
                    Console.ReadKey();
                }
            }
            Console.ReadLine();
            Console.Clear();
            Console.ReadKey();
            while (true)
            {
                Console.WriteLine("Question two: What was Don Diego de la Vegas secret identity?");
                Console.Write("Answer: ");
                string answer2 = "Zorro";
                string userAnswer2;
                userAnswer2 = Console.ReadLine();
                userAnswer2 = userAnswer2.ToLower();
                if (userAnswer2 == answer2)
                {
                    Console.WriteLine("Correct answer. Please press enter for the next question.");
                    HighScore++;
                    break;
                }
                else
                {
                    Console.WriteLine("Wrong answer. Sorry bud, keep at it! Just keep hitting enter 'til you get the   question again.");
                    Console.ReadLine();
                    Console.Clear();
                    Console.ReadKey();

                }
                Console.ReadKey();
            }

        }
    }
}
