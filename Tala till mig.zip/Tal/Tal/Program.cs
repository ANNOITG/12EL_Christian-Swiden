﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tal
{
    class Program
    {
        static void Main(string[] args)
        {
          
            //Användaren matar in ett tal

            Console.WriteLine("Var god skriv ett heltal.");

            Console.WriteLine("Tal 1?");
            string s1 = Console.ReadLine();
            int tal1 = int.Parse(s1);

            Console.WriteLine("Tal 2?");
            string s2 = Console.ReadLine();
            int tal2 = int.Parse(s2);

            //int är vart de flesta uträkningar sparas

            int svar;
            //svar är själva uträkningen

            svar = tal1 + tal2;
           //Skriver ut texten Addition och svaret av de två tal användaren matade in adderade med varandra

            Console.WriteLine("Addition: "+svar);

            //Användaren blir uppmanad och upprepa föregående instruktioner
            Console.WriteLine("Upprepa föregående instruktioner.");
            Console.WriteLine("Tal 1?");
            string s3 = Console.ReadLine();
            int tal3 = int.Parse(s3);

            Console.WriteLine("Tal 2?");
            string s4 = Console.ReadLine();
            int tal4 = int.Parse(s4);

            int svar2;

            svar2 = tal3 - tal4;
            //Själva uträkningen

            Console.WriteLine("Subtraktion: "+svar2);
            //Skriver ut subtraktion och svaret på utträkningen.

            //Återigen blir användaren uppmandad och föra in 2 heltal.
            Console.WriteLine("Nu närmar vi oss slutet. En gång till efter den här så är vi klara sen och mitt vackra konsol-fönster slipper din fula nuna");
            Console.WriteLine("Tal 1?");
            string s5 = Console.ReadLine();
            int tal5 = int.Parse(s5);

            //Jävlas med användaren och lämnar sarkastiska kommentarer innan användaren åter uppmanas att skriva in ett tal.
            Console.WriteLine("Kom igen och var en duktig användare! För mitt vackra consol-fönsters skull!");
            Console.WriteLine("Tal 2?");
            String s6 = Console.ReadLine();
            int tal6 = int.Parse(s6);

            int answer;
            //Sparar uträkningen

            answer = tal5 * tal6;
            //Gör uträkningen

            Console.WriteLine("Multiplikation: "+ answer);
            //Skriver ut multiplikation så användaren vet vilket räknesätt som använts och svaret på användarens 
            //inmatade tal multiplicerade med varandra.

            //Ger användaren instruktioner som förhoppningsvis är tydliga nog för att användaren ska veta vad hen ska göra.
            Console.WriteLine("Nu ska vi krångla till det lite. Du ska bara mata in 1 heltal så kommer programmet dividera det med svaret från vår multiplikation");
            Console.WriteLine("Tal 1?");
            String s7 = Console.ReadLine();
            int tal7 = int.Parse(s7);

            //Då vi kommer avnända division här så är sannolikheten för decimaler hög därav bör double användas istället för int.
            double answe;

            //Gör själva uträkningen. Först gör datorn om uträkningen för multiplikationen sen tar den svaret av det och dividerar
            //med vad användaren matade in vid sista inmatningen.
            //Castar (konverterar) även i7 som är en int till formatet double för och få ut eventuella decimaler.
            answe = (tal5 * tal6) / (double)tal7;

            Console.WriteLine("Division:" + answe);
            //Skriver ut division och svaret på uträkningen ovan.

            Console.WriteLine("Nu är det slut så tryck på en tangent och försvinn från mitt program!");
            //Ber användaren avsluta programmet genom och trycka på en tanget och sedan fara och flyga.

            Console.ReadKey();
          
        }
    }
}
